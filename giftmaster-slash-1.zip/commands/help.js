const { SlashCommandBuilder } = require("@discordjs/builders");
const { MessageEmbed } = require("discord.js");
const config = require("../config.json");
const stock = require("./stock");

module.exports = {
	data: new SlashCommandBuilder()
		.setName("help")
		.setDescription("Display the command list."),

	async execute(interaction) {
		const { commands } = interaction.client;

		const commandListEmbed = new MessageEmbed()
			.setColor(config.color.default)
			.setTitle("Help Panel")
			.setDescription(
				`👋 Merhaba hoşgeldin, **${interaction.guild.name}**! 🌟 Sizlere en iyi hizmetleri sunmak için buradayız. 🚀`,
			)
			.setImage(config.banner)
			.setThumbnail(
				interaction.client.user.displayAvatarURL({ dynamic: true, size: 64 }),
			) // Set the bot's avatar as the thumbnail
			.addFields({
				name: `Commands`,
				value:
					"`/help`   **Yardım komutunu görüntüler**\n`/create` **Yeni bir hizmet oluştur**\n`/free`   **Bir ödül oluştur**\n`/add`    **Hisse senedine ödül ekleme**\n`/stock`  **Mevcut stoğu görüntüle**\n`/premium` **Premium ödülü oluştur**",
			})
			.setFooter(
				interaction.user.tag,
				interaction.user.displayAvatarURL({ dynamic: true, size: 64 }),
			)
			.setTimestamp()
			.addField(
				"Useful Links",
				`[**Website**](${config.website}) [**Discord**](https://discord.gg/kpmkFq8FCv)`,
			);

		await interaction.reply({ embeds: [commandListEmbed] });
	},
};
